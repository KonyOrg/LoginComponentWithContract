define(function() {

	return {
		constructor: function(baseConfig, layoutConfig, pspConfig) {
			this._loginFailureMessage = "Login Failed!";
		},
		//Logic for getters/setters of custom properties
		initGettersSetters: function() {
			defineGetter(this,"loginFailureMessage", function () {
              kony.print("Entering into getter for loginFailureMessage");
              kony.print("Exiting out of getter for loginFailureMessage");
              return this._loginFailureMessage;
            });
          	defineSetter(this, "loginFailureMessage", function (val) {
              kony.print("Entering into setter for loginFailureMessage");
              this._loginFailureMessage=val;
              kony.print("Exiting out of setter for loginFailureMessage");
            });
		},
      	getUsername: function () {
          return this.view.tbxUserName.text;
        },
      
      	getPassword: function () {
          return this.view.tbxPassword.text;
        }
	};
});
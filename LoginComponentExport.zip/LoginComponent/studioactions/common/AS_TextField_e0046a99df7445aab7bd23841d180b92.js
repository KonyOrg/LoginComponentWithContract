function AS_TextField_e0046a99df7445aab7bd23841d180b92(eventobject, changedtext) {
    var self = this;
    if (self.validatePassword) {
        self.validatePassword();
    }
}
function AS_Button_f6bfba80095f407dabbc3736b9f6f729(eventobject) {
    var self = this;

    function INVOKE_IDENTITY_SERVICE__e5d20925596b4317a0919818048e1147_Success(response) {
        if (self.loginSuccessEvent) {
            self.loginSuccessEvent(response);
        }
    }
    function INVOKE_IDENTITY_SERVICE__e5d20925596b4317a0919818048e1147_Failure(error) {
        if (self.loginFailureEvent) {
            self.loginFailureEvent(error);
        }
    }
    if (login_inputparam == undefined) {
        var login_inputparam = {};
    }
    login_inputparam["serviceID"] = "UserRepository$login";
    login_inputparam["operation"] = "login";
    login_inputparam["userid"] = self.view.tbxUserName.text;
    login_inputparam["password"] = self.view.tbxPassword.text;
    UserRepository$login = mfidentityserviceinvoker("UserRepository", login_inputparam, INVOKE_IDENTITY_SERVICE__e5d20925596b4317a0919818048e1147_Success, INVOKE_IDENTITY_SERVICE__e5d20925596b4317a0919818048e1147_Failure);
}
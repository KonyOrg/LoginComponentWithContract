function AS_TextField_g15661516d354eaeb172bc67097a85fa(eventobject, changedtext) {
    var self = this;
    if (self.validateUsername) {
        self.validateUsername();
    }
}
define({ 

  //Type your controller code here 
  loginSuccessCallback: function (response) {
    kony.print("Entering into loginSuccessCallback");
    alert ("In loginSuccessCallback: "+JSON.stringify(response));
    kony.print("Exiting out of loginSuccessCallback");
  },

  loginFailureCallback: function (error) {
    kony.print("Entering into loginFailureCallback");
    alert ("In loginFailureCallback: "+JSON.stringify(error));
    kony.print("Exiting out of loginFailureCallback");
  }
});
define({
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** loginFailureEvent defined for basiclogin **/
    AS_UWI_b3783524f8b0498782ac548eb054aa98: function AS_UWI_b3783524f8b0498782ac548eb054aa98(error) {
        var self = this;
        return self.loginFailureCallback.call(this, error);
    },
    /** loginSuccessEvent defined for basiclogin **/
    AS_UWI_g81930af70884412ac60c65282ad58d3: function AS_UWI_g81930af70884412ac60c65282ad58d3(response) {
        var self = this;
        return self.loginSuccessCallback.call(this, response);
    }
});